#include<stdio.h>
#include<string.h>

int main(){
    char stck[100],in[20];
    int i=0,j=0; 
    stck[j]='$';
    printf("GRAMMAR is E->E+E \n E->E*E \n E->(E) \n E->id\n");
    printf("Enter input : ");
    scanf("%s",in);
   printf("\nstack\tinput \t action\n");
    while(in[i]!='\0'){
        if(in[i]=='i'&& in[i+1]=='d'){
            stck[++j]=in[i];
            in[i++]=' ';
            stck[++j]=in[i];
            in[i++]=' ';
            printf("%s\t %s$\t %s\n",stck,in,"shift->id");
        }
        else{
            stck[++j]=in[i];
            in[i++]=' ';
            printf("%s\t %s$\t %s\n",stck,in,"shift->symbol");
        }
        if(stck[j-1]=='i' && stck[j]=='d'){
            stck[j--]='\0';
            stck[j]='E';
            printf("%s\t %s$\t %s\n",stck,in,"reduce to E");
            }
         if(stck[j-2]=='(' && stck[j-1]=='E' && stck[j]==')'){
         
         	stck[j--]='\0';
         	stck[j--]='\0';
            	stck[j]='E';
            	printf("%s\t %s$\t %s\n",stck,in,"reduce to E");
            }
         if(stck[j-2]=='E' && (stck[j-1]=='+' || stck[j-1]=='*') && stck[j]=='E'){
         	stck[j--]='\0';
         	stck[j--]='\0';
            	stck[j]='E';
            	printf("%s\t %s$\t %s\n",stck,in,"reduce to E");
            }
    }
   	puts(stck);

    return 0;
}
