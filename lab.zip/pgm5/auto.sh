#!/bin/bash

lex $1.l
yacc -y -d $1.y > /dev/null 2>&1 &
gcc lex.yy.c y.tab.c > /dev/null 2>&1 &
./a.out
